package controller;

import Lambda.Lambda2;
import Lambda.LambdaInterface;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;
import util.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

//import static util.CountryUtil.getTheCountry;

/** Class that updates appointments in the database and the GUI. */
public class UpdateAnAppointmentController implements Initializable {

    public TextField appointmentIdTXT;
    public TextField titleTXT;
    public TextField descriptionTXT;
    public TextField locationTXT;
    public TextField contactTXT;
    public TextField typeTXT;
    public TextField startTXT;
    public TextField timeTXT;
    public TextField customerIdTXT;
    public TextField userIdTXT;
    public TextField userNameTXT;
    public TableView appointmentsTable;
    public TableColumn appointmentsColumn;
    public TableColumn titleColumn;
    public TableColumn descriptionColumn;
    public TableColumn locationColumn;
    public TableColumn typeColumn;
    public TableColumn startColumn;
    public TableColumn endColumn;
    public TableColumn create_DateColumn;
    public TableColumn created_By;
    public TableColumn last_Update;
    public TableColumn last_Updated_By;
    public TableColumn customer_ID;
    public TableColumn user_ID;
    public TableColumn contact_ID;
    @FXML
    public DatePicker datePicker;
    @FXML
    public ComboBox<String> hourComboBox;
    @FXML
    public ComboBox<String> minutesComboBox;

    private final ObservableList<String> timeHour = FXCollections.observableArrayList("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12",
            "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
    private final ObservableList<String> timeMinutes = FXCollections.observableArrayList("00", "15", "30", "45");
    private final ObservableList<String> emptyList = FXCollections.observableArrayList("");
    public RadioButton doNotNeedToUpdateAppointmentDate;
    public RadioButton doNeedToUpdateAppointmentDate;
    public TextField updatedDateTimeTXT;
    public TextField updateEndDateTime;
    public TextField nameTxt;

    /** Initializes the Update Appointments page and populates the appointments table in the GUI. The name combo box is
     filled with a list of customer names. */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {

            appointmentsColumn.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
            titleColumn.setCellValueFactory(new PropertyValueFactory<>("Title"));
            descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("Description"));
            locationColumn.setCellValueFactory(new PropertyValueFactory<>("Location"));
            typeColumn.setCellValueFactory(new PropertyValueFactory<>("Type"));
            startColumn.setCellValueFactory(new PropertyValueFactory<>("ldtStart"));
            endColumn.setCellValueFactory(new PropertyValueFactory<>("ldtEnd"));
            create_DateColumn.setCellValueFactory(new PropertyValueFactory<>("Create_Date"));
            created_By.setCellValueFactory(new PropertyValueFactory<>("Created_By"));
            last_Update.setCellValueFactory(new PropertyValueFactory<>("Last_Update"));

            last_Updated_By.setCellValueFactory(new PropertyValueFactory<>("Last_Updated_By"));
            customer_ID.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
            user_ID.setCellValueFactory(new PropertyValueFactory<>("User_ID"));


             appointmentsTable.setItems(AddAppointmentsUtil.getAllAppointmentsLDT());

        } catch (SQLException throwables) {
            throwables.printStackTrace();

        }
    }

    /** Action event that populates the updatable fields with the selected appointment upon pressing the "Select Appointment to
     Update" button. One of the two radio buttons must be selected. They allow you to choose to update an appointment with or without
     updating the date and time. If not updating the date and time, those fields are disabled. If updating the time, both must be reset.
     There are Alerts if no appointment is selected or if neither radio button is selected.
     @param actionEvent actionEvent  */
    public void selectAppointmentToUpdatePushed(ActionEvent actionEvent) throws SQLException, NumberFormatException {

         AddAppointmentsModel selectedAppointment = (AddAppointmentsModel) appointmentsTable.getSelectionModel().getSelectedItem();

        if (selectedAppointment == null) {

            Alert noSelectedAppointment = new Alert(Alert.AlertType.ERROR);
            noSelectedAppointment.setTitle("ERROR");
            noSelectedAppointment.setContentText("You have not selected an appointment to update");
            noSelectedAppointment.showAndWait();
        }

        boolean radioSelected = doNeedToUpdateAppointmentDate.isSelected() || doNotNeedToUpdateAppointmentDate.isSelected();
        {
            if (radioSelected == false) {
                Alert noSelectedAppointment = new Alert(Alert.AlertType.ERROR);
                noSelectedAppointment.setTitle("ERROR");
                noSelectedAppointment.setContentText("First select if you want to update an appointment with or without the changing the date or time.");
                noSelectedAppointment.showAndWait();
                return;
            }
        }


        if (doNotNeedToUpdateAppointmentDate.isSelected()) {

            int appointmentID = selectedAppointment.getAppointment_ID();
            appointmentIdTXT.setText(String.valueOf(selectedAppointment.getAppointment_ID()));
            nameTxt.setText(String.valueOf(NamesUtil.getCustomerName(appointmentID)));
            titleTXT.setText(selectedAppointment.getTitle());
            descriptionTXT.setText(selectedAppointment.getDescription());
            locationTXT.setText(selectedAppointment.getLocation());
            typeTXT.setText(selectedAppointment.getType());
            userNameTXT.setText(String.valueOf(NamesUtil.getUserName(appointmentID)));
            userIdTXT.setText(String.valueOf(selectedAppointment.getUser_ID()));
            customerIdTXT.setText(String.valueOf(selectedAppointment.getCustomer_ID()));
            updatedDateTimeTXT.setText(String.valueOf(selectedAppointment.getLdtStart()));//fixme
            updateEndDateTime.setText(String.valueOf(selectedAppointment.getLdtEnd()));


        } else if (doNeedToUpdateAppointmentDate.isSelected()) {

            int appointmentID = selectedAppointment.getAppointment_ID();
            appointmentIdTXT.setText(String.valueOf(selectedAppointment.getAppointment_ID()));
            nameTxt.setText(String.valueOf(NamesUtil.getCustomerName(appointmentID)));
            titleTXT.setText(selectedAppointment.getTitle());
            descriptionTXT.setText(selectedAppointment.getDescription());
            locationTXT.setText(selectedAppointment.getLocation());
            typeTXT.setText(selectedAppointment.getType());
            userNameTXT.setText(String.valueOf(NamesUtil.getUserName(appointmentID)));
            hourComboBox.setValue(String.valueOf(timeHour));
            minutesComboBox.setValue(String.valueOf(timeMinutes));
            userIdTXT.setText(String.valueOf(selectedAppointment.getUser_ID()));
            customerIdTXT.setText(String.valueOf(selectedAppointment.getCustomer_ID()));
            updatedDateTimeTXT.setText(String.valueOf(selectedAppointment.getLdtStart()));//fixme
            updateEndDateTime.setText(String.valueOf(selectedAppointment.getLdtEnd()));

        }
    }


    /** Saves updated appointment data in the appointments table in the database and the GUI. There's a radio button choice to update
     appointments with a change of date and time or without a change of date and time. If date and time are not changed the original date
     and time stay the same. If they choose the radio button to change the date and time they must both be reset. There are validations that
     all fields are filled, the appointments are set within business hours (8:00am-10:00pm Mon-Fri EST), and there are no overlapping appointments.
     The time is stored in the database as UTC.

     <p><b>There are 2 lambdas.
     Lambda to check if there is already appointment scheduled at the same time. This lambda provides a very efficient way to
     insert ldtStartDatePicker (the Start value from the datePicker) and ldtEndDatePicker (the End value from the datePicker) into
     the parameters s and e and compare them to dbStart and dbEnd (the Start and End values from the database). Using this lambda
     shortened my code and reduced many brackets.

     Lambda to check if the requested appointment time is outside of business our per EST. This lambda provides a very efficient way to
     insert estStartTime and estEndTime (the Start and End time collected from the datePicker) into
     the parameters am and pm and compares them to startOfDay and endOfDay (the given 8:00 and 10:00 hrs respectively). Using this lambda
     shortened my code and reduced many brackets.

     </b></p>

     @param actionEvent actionEvent */
    public void updateAppointmentButtonPressed(ActionEvent actionEvent) throws SQLException {

        if (doNeedToUpdateAppointmentDate.isSelected()) {
            int selectedId = Integer.parseInt(appointmentIdTXT.getText());
            LocalDate date = datePicker.getValue();
            LocalTime timeHour = LocalTime.parse(hourComboBox.getValue() + ":" + minutesComboBox.getValue());
            LocalTime time = LocalTime.parse(timeHour + ":00");
            DayOfWeek day = date.getDayOfWeek();

            LocalDateTime startDateAndTime = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(),
                    timeHour.getHour(), timeHour.getMinute(), time.getSecond());

            //convert start and end from UTC to Timestamp to Insert into the database.
            Timestamp startDatePicker = TimeZoneUtil.getStartUTC(date, timeHour, time);
            Timestamp endDatePicker = TimeZoneUtil.getStartUTC(date, timeHour.plusHours(1), time);
            LocalDateTime ldtStartDatePicker = startDatePicker.toLocalDateTime();
            LocalDateTime ldtEndDatePicker = endDatePicker.toLocalDateTime();

            //Converting datePicker to zones and LocalDateTime.
            ZonedDateTime zonedStart = startDateAndTime.atZone(ZoneId.systemDefault());

            ZonedDateTime estStart = zonedStart.withZoneSameInstant(ZoneId.of("America/New_York"));
            LocalDateTime thisLDTinESTStart = estStart.toLocalDateTime();
            LocalDateTime thisLDTinESTEnd = estStart.plusHours(1).toLocalDateTime();
            LocalTime estStartTime = LocalTime.of(thisLDTinESTStart.getHour(), thisLDTinESTStart.getMinute());
            LocalTime estEndTime = LocalTime.of(thisLDTinESTEnd.getHour(), thisLDTinESTEnd.getMinute());


            LocalTime startOfDay = LocalTime.of(8, 0);
            LocalTime endOfDay = LocalTime.of(20, 0);



            for (AddAppointmentsModel apps : AddAppointmentsUtil.allAppointments) { //fixme

                LocalDateTime dbStart = apps.getLdtStart();
                LocalDateTime dbEnd = apps.getLdtEnd();
                int getDatabaseId = apps.getAppointment_ID();

             //Lambda to check if there is already appointment scheduled at the same time.//fixme good lambda
               /* Lambda2 checkOverlap = (s, e) -> (s.isAfter(dbStart) && s.isBefore(dbEnd)) || (s.isAfter(dbStart) && s.isBefore(dbEnd) && e.isAfter(dbEnd) || (s.isBefore(dbStart) && e.isAfter(dbStart) && e.isBefore(dbEnd)) || (s.equals(dbStart)));
                if (checkOverlap.checkOverLapHours(ldtStartDatePicker, ldtEndDatePicker)) {

                    Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                    invalidTime.setContentText("That time overlaps with an already scheduled appointment.");
                    updatedDateTimeTXT.clear();
                    updateEndDateTime.clear();
                    invalidTime.showAndWait();
                    System.out.println(ldtStartDatePicker + " ldtStartDatePicker" + ldtEndDatePicker + " ldtEndDatePicker"  + dbStart);

                    return;
                }*/

                Lambda2 checkOverlap = (s, e) -> (s.isAfter(dbStart) && s.isBefore(dbEnd)) || (s.isAfter(dbStart) && s.isBefore(dbEnd) && e.isAfter(dbEnd) || (s.isBefore(dbStart) && e.isAfter(dbStart) && e.isBefore(dbEnd)) || (s.equals(dbStart)));
                if (checkOverlap.checkOverLapHours(ldtStartDatePicker, ldtEndDatePicker ))
                if (selectedId != getDatabaseId )
                {

                    Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                    invalidTime.setContentText("That time overlaps with an already scheduled appointment.");
                    updatedDateTimeTXT.clear();
                    updateEndDateTime.clear();
                    invalidTime.showAndWait();
                    System.out.println(ldtStartDatePicker + " ldtStartDatePicker" + ldtEndDatePicker + " ldtEndDatePicker"  + dbStart);

                    return;
                }
            }


           //Lambda to check if the requested appointment time is outside of business our per EST.

            LambdaInterface checkTime = (am, pm) -> am.isBefore(startOfDay) || pm.isAfter(endOfDay);
            if (checkTime.checkBusinessHours(estStartTime, estEndTime)) {
                Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                invalidTime.setContentText("Appointment time must be within business hours of 8:00am - 10:00pm.");
                updatedDateTimeTXT.clear();
                updateEndDateTime.clear();
                invalidTime.showAndWait();
                return;
            }


              //Code to not allow schedules on the weekend.
            if (day.equals(DayOfWeek.SATURDAY) || day.equals(DayOfWeek.SUNDAY)) {

                Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                invalidTime.setContentText("Appointment time must be within business days of Monday - Friday.");
                updatedDateTimeTXT.clear();
                updateEndDateTime.clear();
                invalidTime.showAndWait();
                return;
            }


            if (datePicker.getValue() == null) {
                Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                invalidTime.setContentText("Must choose Date,Hour and Minutes then press \"Update Date and Time\" to update an appointment.");
                invalidTime.showAndWait();
                return;
            }

            if (hourComboBox.getValue() == null) {
                Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                invalidTime.setContentText("Must choose Date,Hour and Minutes then press \"Update Date and Time\" to update an appointment.");
                invalidTime.showAndWait();
                return;
            }

            if (hourComboBox.getValue() == null) {
                Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                invalidTime.setContentText("Must choose Date,Hour and Minutes then press \"Update Date and Time\" to update an appointment.");
                invalidTime.showAndWait();
                return;
            }

            if (updatedDateTimeTXT.getText().isEmpty()) {
                Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                invalidTime.setContentText("Must choose Date,Hour and Minutes then press \"Update Date and Time\" to update an appointment.");
                invalidTime.showAndWait();
                return;
            }


            if (updateEndDateTime.getText().isEmpty()) {
                Alert invalidTime = new Alert(Alert.AlertType.ERROR);
                invalidTime.setContentText("Must choose Date,Hour and Minutes then press \"Update Date and Time\" to update an appointment.");
                invalidTime.showAndWait();
                return;
            } else {

                int Appointment_ID = Integer.parseInt((appointmentIdTXT.getText()));
                String Title = titleTXT.getText();
                String Description = descriptionTXT.getText();
                String Location = locationTXT.getText();
                String Type = typeTXT.getText();
                Timestamp start = startDatePicker;
                Timestamp end = endDatePicker;
                Timestamp Last_Update = Timestamp.valueOf(LocalDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                String Last_Updated_By = userNameTXT.getText();
                int Customer_ID = Integer.parseInt(customerIdTXT.getText());
                int User_ID = Integer.parseInt(userIdTXT.getText());

                UpdateAppointmentUtil.updateAppointmentsTable(Appointment_ID, Title, Description,
                        Location, Type, start, end, Last_Update, Last_Updated_By, Customer_ID, User_ID);
                //appointmentsTable.setItems(UpdateAppointmentUtil.getAllAppointments()); //fixme
                appointmentsTable.setItems(AddAppointmentsUtil.getAllAppointmentsLDT());

            }
        } else if (doNotNeedToUpdateAppointmentDate.isSelected()) {

            int Appointment_ID = Integer.parseInt((appointmentIdTXT.getText()));
            String Title = titleTXT.getText();
            String Description = descriptionTXT.getText();
            String Location = locationTXT.getText();
            String Type = typeTXT.getText();
            Timestamp Last_Update = Timestamp.valueOf(LocalDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            String Last_Updated_By = userNameTXT.getText();
            int Customer_ID = Integer.parseInt(customerIdTXT.getText());
            int User_ID = Integer.parseInt(userIdTXT.getText());

            if (titleTXT.getText().isEmpty() || descriptionTXT.getText().isEmpty() || locationTXT.getText().isEmpty() || typeTXT.getText().isEmpty()) {
                Alert invalidEntry = new Alert(Alert.AlertType.ERROR);
                invalidEntry.setContentText("All fields must be filled.");
                invalidEntry.showAndWait();
                return;
            }


            UpdateAppointmentUtil.updateAppointmentsTableWithOutDateTime(Appointment_ID, Title, Description,
                    Location, Type, Last_Update, Last_Updated_By, Customer_ID, User_ID);
            //appointmentsTable.setItems(UpdateAppointmentUtil.getAllAppointments()); //fixme
            appointmentsTable.setItems(AddAppointmentsUtil.getAllAppointmentsLDT());
        }


        appointmentIdTXT.clear();
        titleTXT.clear();
        descriptionTXT.clear();
        locationTXT.clear();
        typeTXT.clear();
        userNameTXT.clear();
        updatedDateTimeTXT.clear();
        updateEndDateTime.clear();
        userNameTXT.setText(null);
        datePicker.setValue(null);
        hourComboBox.setValue(null);
        minutesComboBox.setValue(null);
        userIdTXT.clear();
        customerIdTXT.clear();

    }

/** Deletes the selected appoointment upon pressing the "Delete Appointment Button" There are alerts if no appointment is selected.
 @param actionEvent  actionEvent */
    public void deleteAppointmentButtonPressed(ActionEvent actionEvent) throws SQLException {
        AddAppointmentsModel selectedAppointment = (AddAppointmentsModel) appointmentsTable.getSelectionModel().getSelectedItem();

        if (selectedAppointment == null) {

            Alert noSelectedAppointment = new Alert(Alert.AlertType.ERROR);
            noSelectedAppointment.setTitle("ERROR");
            noSelectedAppointment.setContentText("You have not selected an appointment to cancel");
            noSelectedAppointment.showAndWait();

        } else {
            int appointmentID = selectedAppointment.getAppointment_ID();
            String appointmentType = selectedAppointment.getType();
            Alert deleteAlert = new Alert(Alert.AlertType.WARNING);
            deleteAlert.setTitle("WARNING");
            deleteAlert.setContentText("Are you sure you want to cancel Appointment ID: " + appointmentID + " of Type: " + appointmentType + "?");
            deleteAlert.showAndWait();

        }

        int appointmentID = selectedAppointment.getAppointment_ID();
        UpdateAppointmentUtil.deleteAppointment(appointmentID);
        Alert deletedAppt = new Alert(Alert.AlertType.CONFIRMATION);
        deletedAppt.setContentText("Appointment deleted");
        deletedAppt.showAndWait();

        System.out.println("Appointment deleted");
        //appointmentsTable.setItems(UpdateAppointmentUtil.getAllAppointmentsLDT());//fixme
        appointmentsTable.setItems(AddAppointmentsUtil.getAllAppointmentsLDT());

    }


    /** Action event that switches the user to the "Menu Page" page.
     @param actionEvent actionEvent */
    public void goBackToMenuPageButtonPressed(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/menuPage.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 500, 900.0));
        stage.show();
    }

    /** Actions event that disables the datePicker, and hour and minutes combo boxes if the "Do NOT Need to Update
     Appointment Date and Time" radio button is selected.
     @param actionEvent actionEvent */
    public void doNotNeedToUpdateAppointmentDateIsSelected(ActionEvent actionEvent) throws IOException {

        datePicker.getEditor().setDisable(true);
        hourComboBox.isDisabled();
        minutesComboBox.isDisabled();
    }

/** Action event that fills the hour and minutes combo box if the " Do Need To Update Appointment Date and Time"
 radio button is selected. */

    public void doNeedToUpdateAppointmentDateIsSelected(ActionEvent actionEvent) throws IOException {
        if (doNeedToUpdateAppointmentDate.isSelected()) {
            hourComboBox.setItems(timeHour);
            minutesComboBox.setItems(timeMinutes);

        }
    }

    /** Action event that takes populates a field with the selected date and time and combines it to and LocalDateTime.
     @param actionEvent actionEvent */
    public void updateDateTimeButtonPressed(ActionEvent actionEvent) throws SQLException {

        if (doNotNeedToUpdateAppointmentDate.isSelected()) {
            Alert nameField = new Alert(Alert.AlertType.ERROR);
            nameField.setTitle("ERROR");
            nameField.setContentText("You have selected \"Do not need to update appointment date and time above. if you wish to " +
                    "update the date and time, change your selection above to \"Do need to update appointment date and time\".");
            nameField.showAndWait();
            return;
        }

        try {
            LocalDate date = datePicker.getValue();
            LocalTime timeHour = LocalTime.parse(hourComboBox.getValue() + ":" + minutesComboBox.getValue());
            LocalTime time = LocalTime.parse(timeHour + ":00");
            LocalTime endTimeHour = timeHour.plusHours(1);


            LocalDateTime updatedStart = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), timeHour.getHour(), timeHour.getMinute(), time.getSecond());
            LocalDateTime updatedEnd = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), endTimeHour.getHour(), timeHour.getMinute(), time.getSecond());

            updatedDateTimeTXT.setText(String.valueOf(updatedStart));
            updateEndDateTime.setText(String.valueOf(updatedEnd));


        } catch (DateTimeParseException e) {
            Alert nameField = new Alert(Alert.AlertType.ERROR);
            nameField.setTitle("ERROR");
            nameField.setContentText("Must select Date, Hours, and Minutes to update an appointment.");

            nameField.showAndWait();

        }
        catch (NullPointerException n) {
            Alert nameField = new Alert(Alert.AlertType.ERROR);
            nameField.setTitle("ERROR");
            nameField.setContentText("Must select Date, Hours, and Minutes to update an appointment.");

            nameField.showAndWait();
        }
    }
}




