package Lambda;

import java.time.LocalDateTime;


/** Interface containing the Lambda constructor. Lambda to check overlapping appointment times. */
public interface Lambda2 {
    boolean checkOverLapHours(LocalDateTime s, LocalDateTime e);

}

