package Lambda;

import java.time.LocalTime;

/** Interface containing the Lambda constructor. Lambda to check beginning and ending business hours. */

public interface LambdaInterface {

            boolean checkBusinessHours(LocalTime am, LocalTime pm);

            }







