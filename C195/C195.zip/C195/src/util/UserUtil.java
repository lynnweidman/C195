package util;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import model.UserModel;


/** This class is used to get all users from the database. */
public class UserUtil {
    public static ObservableList<UserModel> allUsers = FXCollections.observableArrayList();

    /**
     * This method SELECTS ALL from the users database. It adds all users to the allUser ObservableList.
     */

    public static void getUser() throws SQLException {
        //allUsers.clear();
        String sql = "SELECT * from users";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int dbID = rs.getInt("User_ID");
            String dbName = rs.getString("user_name");
            String dbPassword = rs.getString("password");
            UserModel user = new UserModel(dbID, dbName, dbPassword);
            allUsers.add(user);
        }
    }
}













