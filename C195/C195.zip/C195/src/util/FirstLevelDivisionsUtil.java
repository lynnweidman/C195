package util;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FirstLevelDivisionModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** This class is used to get the first_level_divisions (states) from the database. */
public class FirstLevelDivisionsUtil {

    public static ObservableList<FirstLevelDivisionModel> allDivisions = FXCollections.observableArrayList();
    public static ObservableList<FirstLevelDivisionModel> theDivision = FXCollections.observableArrayList();

    /** Method to get the first_level_divisions based on matching countryId from the first_level_divisions table.
     @return  allDivisions based on the input of a countryId. */
    public static ObservableList<FirstLevelDivisionModel> getAllDivisions(int countryId) throws SQLException {
     allDivisions.clear();
        String sql = "SELECT * " +
                "FROM first_level_divisions " +
                "WHERE Country_Id = ?";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ps.setInt(1, countryId);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            int divisionId = rs.getInt("Division_Id");
            String division = rs.getString("Division");
            FirstLevelDivisionModel d = new FirstLevelDivisionModel(divisionId, division);
            allDivisions.add(d);
        }
        return allDivisions;
    }

    /** Method to get the division based on division_id.
     * @param Division_ID Division_ID */
 public static ObservableList<FirstLevelDivisionModel> getTheDivision (int Division_ID) throws SQLException {
        theDivision.clear();
        String sql = "SELECT Division FROM first_level_divisions WHERE Division_ID = ?";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ps.setInt(1, Division_ID);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String division = rs.getString("Division");
            FirstLevelDivisionModel d = new FirstLevelDivisionModel( division);
            theDivision.add(d);
        }
        return theDivision;

    }


}








